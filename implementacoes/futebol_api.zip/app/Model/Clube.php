<?php

namespace App\Model;

use \JsonSerializable;

class Clube implements JsonSerializable {

    private ?int $id;
    private ?string $nome;
    private ?string $cidade;
    private ?string $imagem;

    public function __construct() {
        $this->id = 0;
        $this->nome = null;
        $this->cidade = null;
        $this->imagem = null;
    }

    public function jsonSerialize(): array
    {
        return array(
            "id" => $this->id,
            "nome" => $this->nome,
            "cidade" => $this->cidade,
            "imagem" => $this->imagem
        );
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */ 
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     *
     * @return  self
     */ 
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of cidade
     */ 
    public function getCidade()
    {
        return $this->cidade;
    }

    /**
     * Set the value of cidade
     *
     * @return  self
     */ 
    public function setCidade($cidade)
    {
        $this->cidade = $cidade;

        return $this;
    }

    /**
     * Get the value of imagem
     */ 
    public function getImagem()
    {
        return $this->imagem;
    }

    /**
     * Set the value of imagem
     *
     * @return  self
     */ 
    public function setImagem($imagem)
    {
        $this->imagem = $imagem;

        return $this;
    }

}