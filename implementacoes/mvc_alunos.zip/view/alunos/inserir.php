<?php

//Verificar se o usuário clicou no gravar
if(isset($_POST['nome'])) {
    echo "Já clicou!";
    //Capturar os valores preechidos no formulário

}


include_once(__DIR__ . "/form.php");
?>